<?php
// Conexión a la base de datos
$mysqli = new mysqli("localhost", "root", "", "paty_sport");
if ($mysqli->connect_errno) {
    die("Error al conectar: " . $mysqli->connect_error);
}


if (isset($_GET['token'])) {
    $token = $_GET['token'];

    // Verificar si el token es válido y no ha expirado
    $sql = "
        SELECT usuario.* 
        FROM usuario
        INNER JOIN login ON usuario.Num_Documento = login.Num_Documento
        WHERE login.token = '$token' AND login.token_expiry > NOW()
    ";
    $resultado = $mysqli->query($sql);

    if ($resultado && $resultado->num_rows > 0) {
        $usuario = $resultado->fetch_assoc();
    } else {
        echo "<h1>El enlace es inválido o ha expirado.</h1>";
        exit;
    }
} else {
    echo "<h1>Token no proporcionado.</h1>";
    exit;
}?>


<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="icono1.jpg" type="image/x-icon">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
        <link rel="stylesheet" href="../estilos.css">
    <title>Confirmar contraseña- PATY SPORT</title>
</head>

<!-- Inicio de encabezado-->

<body class="top-margin">
    <nav class="navbar navbar-dark bg-dark">
        <!-- Navbar content -->
        <div class="container-fluid">
            <a class="navbar-brand" href="index.html">Inicio</a>
            <a class="navbar-brand" href="#">Deporte & Estilo</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText"
                aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarText">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Iniciar sesión</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Conocenos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Contactenos</a>
                    </li>
                </ul>

            </div>
        </div>
    </nav>

    <!-- Fin de encabezado-->

    <body style="
      background-image: url('https://img.freepik.com/fotos-premium/fondo-imagen-borrosa-tienda-ropa_74333-364.jpg');
      background-size: cover; /* Fills the entire body area */
      background-repeat: no-repeat; /* Image won't repeat itself */
      background-position: center; /* Image starts at the center */
    ">



<div class="whatsapp-float" id="whatsapp-btn">
    <img src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" alt="WhatsApp">
</div>



<style>



.whatsapp-float {
position: fixed;
bottom: 20px;
right: 20px;
width: 60px;
height: 60px;
background-color: #25d366;
border-radius: 50%;
display: flex;
align-items: center;
justify-content: center;
box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
cursor: pointer;
z-index: 1000;
transition: transform 0.3s ease;
}

.whatsapp-float img {
width: 35px;
height: 35px;
}

.whatsapp-float:hover {
transform: scale(1.1);
}

</style>

        <div class="container">

            <div class="form-container">
                <h2 class="text-center">Recuperar contraseña</h2>
                <form action="contraseñaNueva.php" method="post">
                    <div class="form-group">
                        <label for="password">Contraseña</label>
                        <input type="hidden" name="Num_Documento" value="<?php echo $usuario['Num_Documento']; ?>">
              <div class="correo">
                <input type="password" name="nueva_contrasena" id="contrasena" required>
              </div>
              <input type="checkbox" onclick="myFunction()"> <i class="bi bi-eye-fill"></i> Ver Contraseña
                    </div>
                    <br>
                        <button type="submit" class="btn btn-primary btn-block">Aceptar</button>
                        <hr>
                        <p class="text-center mt-3">¿Ya tienes una cuenta? <a href="../Inicio/InicioSesionIndex.html">Iniciar
                                sesión</a></p>
                </form>
            </div>
        </div>

        <footer
            style="margin-top: 50px; padding: 20px; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; background-color: #000000; color: #fff;  text-align: center;">
            <h2 class="footer2" style="font-size: 17px; ">Contacto: Patysport69@gmail.com | Teléfono: 3102283419</h2>
        </footer>
        <script>
            function scrollToSection(id) {
                document.getElementById(id).scrollIntoView({ behavior: 'smooth' });
            }

            let currentSlide = 0;
            const slides = document.querySelectorAll('.slides img');
            const totalSlides = slides.length;

            function showSlide(index) {
                slides.forEach((slide, i) => {
                    slide.style.display = i === index ? 'block' : 'none';
                });
            }

            function nextSlide() {
                currentSlide = (currentSlide + 1) % totalSlides;
                showSlide(currentSlide);
            }

            setInterval(nextSlide, 5000); // Cambia de imagen cada 3 segundos
            showSlide(currentSlide);
        </script>



<script>
    function myFunction() {
  var x = document.getElementById("contrasena");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
  </script>


<!-- Optional JavaScript; choose one of the two! -->

<!-- Option 1: Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
    crossorigin="anonymous"></script>

<!-- Option 2: Separate Popper and Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>

</body>

</html>

