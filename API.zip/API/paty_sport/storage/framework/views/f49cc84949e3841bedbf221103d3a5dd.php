<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'My Application'); ?></title>
</head>
<body>
    <header>
        <nav>
            <!-- Aquí puedes agregar tu menú o barra de navegación -->
        </nav>
    </header>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer>
        <!-- Pie de página -->
    </footer>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\paty_sport\resources\views/layouts/app.blade.php ENDPATH**/ ?>