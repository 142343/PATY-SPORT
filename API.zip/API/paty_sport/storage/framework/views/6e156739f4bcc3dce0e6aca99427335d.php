

<?php $__env->startSection('styles'); ?>
<link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
<style>
    /* Animación del título PATY SPORT */
    @keyframes moverTexto {
        0% { transform: translateX(-20%); }
        50% { transform: translateX(0); }
        100% { transform: translateX(20%); }
    }

    .texto {
        width: 100%;
        color: transparent;
        text-align: center;
        font-size: 100px;
        font-weight: bold;
        background-image: url('https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcS7q1RtQN_D1_cTtZcIywD9w_Y-qwzfOfjjPEAQpHJac2Z9dweT');
        background-size: cover;
        background-position-y: 300px;
        background-clip: text;
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        position: relative;
        animation: moverTexto 4s ease-in-out infinite;
        display: inline-block;
    }

    /* Estilos de botones y tabla */
    .btn {
        font-family: 'Arial', sans-serif;
        font-size: 14px;
        font-weight: bold;
        padding: 8px 15px;
        border-radius: 8px;
        border: none;
        cursor: pointer;
        transition: all 0.3s ease;
        outline: none;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .btn:hover {
        transform: translateY(-3px);
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
    }

    /* Estilos del modal */
    .modal-custom {
        display: none;
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 50%;
        z-index: 1050;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .modal-custom.active {
        display: block;
    }

    .overlay {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        z-index: 1040;
    }

    .overlay.active {
        display: block;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <nav class="navbar navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Volver</a>
            <a class="navbar-brand" href="#">Deporte & Estilo</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarText">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" href="<?php echo e(route('logout')); ?>">Cerrar Sesión</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="hero">
        <h1 class="texto">PATY SPORT</h1>
    </div>

    <section class="py-5">
        <div class="container px-4 px-lg-5">
            <div class="row">
                <div class="col-md-12">
                    <button class="btn btn-warning" id="btnActualizarCarrito">
                        <i class="bi bi-arrow-clockwise"></i> Actualizar
                    </button>
                    <button class="btn btn-danger" id="btnVaciarCarrito">
                        <i class="bi bi-trash"></i> Vaciar
                    </button>
                    <button class="btn btn-danger" id="btnEliminarSeleccionados">
                        Eliminar Seleccionados
                    </button>
                    
                    <div class="table-responsive mt-4" style="background-color: rgba(255, 255, 255, 0.9); border-radius: 10px; box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2); padding: 20px;">
                        <table class="table table-hover">
                            <thead>
                                <tr style="background-color: #007bff; color: white; text-align: center;">
                                    <th><input type="checkbox" id="select-all" class="form-check-input"></th>
                                    <th>#</th>
                                    <th>Producto</th>
                                    <th>Precio</th>
                                    <th>Cantidad</th>
                                    <th>Sub Total</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody id="tblCarrito">
                                <!-- El contenido se llenará dinámicamente con JavaScript -->
                            </tbody>
                        </table>
                        <div class="col-md-5 ms-auto">
                            <h3 class="text-end" id="totalAmount">Total: $0.00</h3>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Botón de Comprar -->
            <div class="text-center mt-4">
                <button id="buyBtn" class="btn btn-primary">Comprar</button>
            </div>

            <!-- Modal de Orden de Compra -->
            <div id="orderModal" class="modal-custom">
                <div class="modal-header" style="background-color: #007bff;">
                    <h5 class="modal-title">Orden de Compra</h5>
                    <button id="closeModalBtn" class="btn-close"></button>
                </div>
                <div class="modal-body">
                    <form id="contactForm" action="https://formspree.io/f/mwpkaaey" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="email" class="form-label">Correo</label>
                            <input type="email" name="email" class="form-control" id="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="name" class="form-label">Nombre</label>
                            <input type="text" name="name" class="form-control" id="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="phone" class="form-label">Teléfono</label>
                            <input type="number" name="phone" class="form-control" id="phone" required>
                        </div>
                        <div class="mb-3">
                            <label for="details" class="form-label">Detalle</label>
                            <textarea id="details" name="details" class="form-control" rows="10" readonly 
                                      style="background-color: #e3f6ff; font-weight: bold; color: #444;"></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="total" class="form-label">Total</label>
                            <input type="text" id="total" name="total" class="form-control" readonly>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success">Enviar</button>
                        </div>
                    </form>
                </div>
            </div>
            <div id="overlay" class="overlay"></div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    // Función para actualizar la tabla del carrito
    function updateCartTable() {
        const carrito = JSON.parse(localStorage.getItem('carrito')) || [];
        const tbody = document.getElementById('tblCarrito');
        tbody.innerHTML = '';
        let total = 0;

        carrito.forEach((producto, index) => {
            const subtotal = producto.precio * producto.cantidad;
            total += subtotal;
            
            const tr = document.createElement('tr');
            tr.id = `producto-${producto.id}`;
            tr.innerHTML = `
                <td><input type="checkbox" class="select-producto" data-id="${producto.id}"></td>
                <td>${index + 1}</td>
                <td>${producto.nombre}</td>
                <td>$${producto.precio.toFixed(2)}</td>
                <td>${producto.cantidad}</td>
                <td>$${subtotal.toFixed(2)}</td>
                <td>
                    <button class="btn btn-danger btn-sm eliminar-producto" data-id="${producto.id}">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            `;
            tbody.appendChild(tr);
        });

        document.getElementById('totalAmount').innerHTML = `Total: $${total.toFixed(2)}`;
    }

    // Evento para seleccionar/deseleccionar todos
    document.getElementById('select-all').addEventListener('change', function() {
        const checkboxes = document.querySelectorAll('.select-producto');
        checkboxes.forEach(checkbox => checkbox.checked = this.checked);
    });

    // Evento para eliminar productos seleccionados
    document.getElementById('btnEliminarSeleccionados').addEventListener('click', function() {
        const selectedProducts = document.querySelectorAll('.select-producto:checked');
        let carrito = JSON.parse(localStorage.getItem('carrito')) || [];

        selectedProducts.forEach(checkbox => {
            const productoId = checkbox.getAttribute('data-id');
            carrito = carrito.filter(producto => producto.id !== productoId);
            const row = document.getElementById('producto-' + productoId);
            if (row) row.remove();
        });

        localStorage.setItem('carrito', JSON.stringify(carrito));
        updateCartTable();
    });

    // Evento para vaciar carrito
    document.getElementById('btnVaciarCarrito').addEventListener('click', function() {
        if (confirm('¿Estás seguro de que deseas vaciar el carrito?')) {
            localStorage.removeItem('carrito');
            updateCartTable();
        }
    });

    // Modal de compra
    const buyBtn = document.getElementById('buyBtn');
    const closeModalBtn = document.getElementById('closeModalBtn');
    const orderModal = document.getElementById('orderModal');
    const overlay = document.getElementById('overlay');

    buyBtn.addEventListener('click', () => {
        const carrito = JSON.parse(localStorage.getItem('carrito')) || [];
        if (carrito.length === 0) {
            Swal.fire('Error', 'El carrito está vacío', 'error');
            return;
        }

        let detalles = '';
        let total = 0;
        
        carrito.forEach(producto => {
            const subtotal = producto.precio * producto.cantidad;
            detalles += `${producto.nombre} - Cantidad: ${producto.cantidad} - Subtotal: $${subtotal.toFixed(2)}\n`;
            total += subtotal;
        });

        document.getElementById('details').value = detalles;
        document.getElementById('total').value = `$${total.toFixed(2)}`;
        
        orderModal.classList.add('active');
        overlay.classList.add('active');
    });

    closeModalBtn.addEventListener('click', () => {
        orderModal.classList.remove('active');
        overlay.classList.remove('active');
    });

    // Manejo del formulario
    document.getElementById('contactForm').addEventListener('submit', async function(e) {
        e.preventDefault();

        const formData = new FormData(this);
        try {
            const response = await fetch(this.action, {
                method: 'POST',
                body: formData,
                headers: {
                    'Accept': 'application/json'
                }
            });

            if (response.ok) {
                Swal.fire({
                    title: '¡Formulario enviado!',
                    html: `
                        <p>Tu Orden ha sido enviada correctamente a la empresa.</p>
                        <p><i class="fas fa-phone-alt" style="color: #007bff; font-size: 24px;"></i></p>
                        <p>Pronto nos contactaremos contigo para confirmar la compra.</p>
                    `,
                    icon: 'success',
                    confirmButtonText: 'Volver al catálogo',
                }).then(() => {
                    localStorage.removeItem('carrito');
                    window.location.href = '/';
                });
            }
        } catch (error) {
            Swal.fire('Error', 'No se pudo enviar el formulario', 'error');
        }
    });

    // Inicializar la tabla al cargar la página
    document.addEventListener('DOMContentLoaded', updateCartTable);
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\paty_sport\resources\views/cart.blade.php ENDPATH**/ ?>